/**
 * 相位状态机单测：用假时钟驱动，不依赖 DSH / Cordis / 任务栏。
 *   node test/plugin-state.test.mjs
 */

import assert from 'node:assert/strict'
import { createPhaseMachine } from '../lib/machine.js'
import { PHASE } from '../lib/status-map.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/** 造一台机器 + 假时钟，并记录每一次相位回调。 */
function harness(overrides = {}) {
  let clock = 1_000_000
  const phases = []
  const machine = createPhaseMachine({
    config: {
      scope: 'roots',
      completion: 'hold',
      completionHoldMs: 30_000,
      errorHoldMs: 60_000,
      logStateChanges: false,
      ...overrides,
    },
    onPhase: (phase, meta) => phases.push({ phase, ...meta }),
    now: () => clock,
  })
  return {
    machine,
    phases,
    /** 当前相位 */
    get current() {
      return machine.phase
    },
    /** 推进假时钟 */
    advance(ms) {
      clock += ms
    },
    /** 最后一次回调的相位 */
    get last() {
      return phases.at(-1)?.phase
    },
    reset() {
      phases.length = 0
    },
  }
}

console.log('phase machine')

check('初始 → idle', () => {
  const h = harness()
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE)
  h.machine.dispose()
})

check('有会话在跑 → working', () => {
  const h = harness()
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.dispose()
})

check('跑完 → done（保持期），到期 → idle', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.setRunning('s1', false)
  assert.equal(h.current, PHASE.DONE, '停止后应进入完成态')
  h.advance(29_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.DONE, '保持期内应仍是完成态')
  h.advance(2_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE, '保持期结束后应清除')
  h.machine.dispose()
})

check("completion='clear' 时跑完直接 idle", () => {
  const h = harness({ completion: 'clear' })
  h.machine.setRunning('s1', true)
  h.machine.setRunning('s1', false)
  assert.equal(h.current, PHASE.IDLE)
  h.machine.dispose()
})

check('等待用户 → waiting，且优先级高于 working', () => {
  const h = harness()
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.setWaiting('s1', true)
  assert.equal(h.current, PHASE.WAITING, '等待应压过运行中')
  h.machine.setWaiting('s1', false)
  assert.equal(h.current, PHASE.WORKING, '回答完应回到运行中')
  h.machine.dispose()
})

check('故障 → error，且优先级高于 waiting / working', () => {
  const h = harness()
  h.machine.setRunning('s1', true)
  h.machine.setWaiting('s1', true)
  assert.equal(h.current, PHASE.WAITING)
  h.machine.markError('s1', 'boom')
  assert.equal(h.current, PHASE.ERROR, '故障应压过等待')
  h.machine.dispose()
})

check('粘性故障：同一条错误重复上报只触发一次', () => {
  const h = harness()
  assert.equal(h.machine.markError('s1', 'boom'), true, '首次应视为新故障')
  assert.equal(h.phases.length, 1, '第一次应触发')
  h.reset()
  // 连续重复同一条错误（模拟 lastAgentError 是粘性的）
  for (let i = 0; i < 5; i += 1) {
    assert.equal(h.machine.markError('s1', 'boom'), false, '同内容应被去重')
  }
  assert.equal(h.phases.length, 0, '内容没变不应重复触发')
  h.machine.dispose()
})

check('故障内容变化 → 视为新故障并刷新保持期', () => {
  const h = harness({ errorHoldMs: 60_000 })
  h.machine.markError('s1', 'boom')
  h.advance(50_000)
  // 新故障：相位本来就是 error，视觉不变所以不必重发相位回调，但保持期必须被刷新
  assert.equal(h.machine.markError('s1', 'different failure'), true, '内容变化应视为新故障')
  h.advance(50_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.ERROR, '保持期应被新故障刷新（否则这里会消退成 idle）')
  h.machine.dispose()
})

check('故障按 errorHoldMs 自动消退', () => {
  const h = harness({ errorHoldMs: 60_000 })
  h.machine.markError('s1', 'boom')
  assert.equal(h.current, PHASE.ERROR)
  h.advance(59_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.ERROR, '消退期内应保持红色')
  h.advance(2_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE, '消退后应清除')
  h.machine.dispose()
})

check('errorHoldMs=0 表示不自动消退', () => {
  const h = harness({ errorHoldMs: 0 })
  h.machine.markError('s1', 'boom')
  h.advance(10 * 60_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.ERROR, '0 应视为永久保持')
  h.machine.dispose()
})

check('重新开始跑 → 清掉该会话上一次的故障', () => {
  const h = harness()
  h.machine.markError('s1', 'boom')
  assert.equal(h.current, PHASE.ERROR)
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING, '重新运行应压过旧故障')
  h.machine.dispose()
})

check('子代理状态不覆盖顶层会话（scope=roots 过滤）', () => {
  const h = harness()
  h.machine.setTopLevelFilter((id) => id === 'top')
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE)
  h.reset()
  h.machine.setRunning('sub-agent', true)
  assert.equal(h.current, PHASE.IDLE, '非顶层会话的运行状态应被忽略')
  h.reset()
  h.machine.markError('sub-agent', 'child failed')
  assert.equal(h.current, PHASE.IDLE, '非顶层会话的故障应被忽略')
  h.machine.setRunning('top', true)
  assert.equal(h.current, PHASE.WORKING, '顶层会话正常运行')
  h.machine.dispose()
})

check('forgetSession 会清掉运行/等待/故障', () => {
  const h = harness()
  h.machine.setRunning('s1', true)
  h.machine.markError('s1', 'boom')
  h.machine.forgetSession('s1')
  assert.equal(h.current, PHASE.IDLE)
  h.machine.dispose()
})

check('reconcileRunning 用权威列表整体校准（含剔除已消失会话）', () => {
  const h = harness()
  h.machine.reconcileRunning([{ id: 'a', status: 'running' }, { id: 'b', status: 'idle' }])
  assert.equal(h.current, PHASE.WORKING)
  // 轮询发现 a 已经空闲 → 应转完成态
  h.machine.reconcileRunning([{ id: 'a', status: 'idle' }])
  assert.equal(h.current, PHASE.DONE)
  // b 从列表里消失也不该有残留
  h.machine.reconcileRunning([])
  assert.equal(h.current, PHASE.DONE, '无运行会话时保持完成态（保持期内）')
  h.machine.dispose()
})

check('未知 status 值不改动运行集合', () => {
  const h = harness({ completion: 'clear' })
  h.machine.setRunning('a', true)
  h.machine.reconcileRunning([{ id: 'a', status: 'some-future-status' }])
  assert.equal(h.current, PHASE.WORKING, '不认识的 status 不应把运行中误判为空闲')
  h.machine.dispose()
})

check('多会话聚合：任何一个在跑就是 working', () => {
  const h = harness({ completion: 'clear' })
  h.machine.setRunning('a', true)
  h.machine.setRunning('b', true)
  h.machine.setRunning('a', false)
  assert.equal(h.current, PHASE.WORKING, 'b 还在跑')
  h.machine.setRunning('b', false)
  assert.equal(h.current, PHASE.IDLE)
  h.machine.dispose()
})

check('会话被关闭/消失不算"任务完成"（不点亮绿色完成条）', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.forgetSession('s1')
  assert.equal(h.current, PHASE.IDLE, '拆卸不该显示完成')
  h.machine.dispose()
})

check('会话从权威列表里消失也不算完成，但显式 idle 算', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.setRunning('a', true)
  // a 直接从列表里消失（被回收）→ 不该点亮完成条
  h.machine.reconcileRunning([])
  assert.equal(h.current, PHASE.IDLE, '消失 ≠ 完成')
  // 显式 idle → 算完成
  h.machine.setRunning('b', true)
  h.machine.reconcileRunning([{ id: 'b', status: 'idle' }])
  assert.equal(h.current, PHASE.DONE, '显式 idle 应算完成')
  h.machine.dispose()
})

check('完成保持期内重复 recompute 不会重复下发（原本会白发 20 次）', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.setRunning('s1', true)
  h.machine.setRunning('s1', false)
  assert.equal(h.last, PHASE.DONE)
  h.reset()
  for (let i = 0; i < 20; i += 1) {
    h.advance(1_000)
    h.machine.recompute()
  }
  assert.equal(h.phases.length, 0, `保持期内应保持静默，实际收到 ${JSON.stringify(h.phases)}`)
  h.advance(11_000)
  h.machine.recompute()
  assert.equal(h.last, PHASE.IDLE, '30 秒后应转 idle')
  h.machine.dispose()
})

check('保持期内又完成一次 → 重新点亮完成态（带 force）', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.reconcileRunning([{ id: 'a', status: 'running' }])
  h.machine.reconcileRunning([{ id: 'a', status: 'idle' }])
  assert.equal(h.last, PHASE.DONE)
  h.reset()
  h.machine.reconcileRunning([{ id: 'a', status: 'running' }])
  h.machine.reconcileRunning([{ id: 'a', status: 'idle' }])
  assert.equal(h.last, PHASE.DONE, '第二次完成应重新点亮')
  assert.equal(h.phases.at(-1).force, true, '相位没变时必须带 force 才会重发')
  h.machine.dispose()
})

console.log(`\nphase machine: ${passed} 项全部通过\n`)
