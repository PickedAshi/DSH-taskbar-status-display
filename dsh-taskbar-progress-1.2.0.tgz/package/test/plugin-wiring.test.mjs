/**
 * 插件接线单测：用假 Cordis 上下文驱动真实的 `apply()`，验证
 * 「DSH 事件 → 状态机 → 相位」这条链，以及配置规整、清理、诊断日志。
 *
 *   node test/plugin-wiring.test.mjs
 *
 * 不需要 DSH、不需要 koffi、不碰真实任务栏（backend 固定为 none）。
 */

import assert from 'node:assert/strict'
import { existsSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { apply, name } from '../lib/index.js'
import { setToastTransport } from '../lib/notify.js'
import { setActivityProbe } from '../lib/activity.js'
import { PHASE } from '../lib/status-map.js'

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

let passed = 0
const check = async (label, fn) => {
  await fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/** 一个刚好够用的假 Cordis ctx。 */
function createFakeCtx(services = {}) {
  const handlers = new Map()
  const effects = []
  const logs = []
  return {
    logs,
    logger: {
      info: (m) => logs.push(['info', m]),
      warn: (m) => logs.push(['warn', m]),
      error: (m) => logs.push(['error', m]),
    },
    get: (key) => services[key],
    on(event, fn) {
      if (!handlers.has(event)) handlers.set(event, [])
      handlers.get(event).push(fn)
      return () => {
        const list = handlers.get(event) ?? []
        const index = list.indexOf(fn)
        if (index >= 0) list.splice(index, 1)
      }
    },
    effect(fn) {
      const disposer = fn()
      effects.push(disposer)
      return () => disposer?.()
    },
    /** 逐个调用该事件的监听器（waterfall 需要把 next 当最后一个参数传进来）。 */
    async emit(event, ...args) {
      let result
      for (const fn of [...(handlers.get(event) ?? [])]) result = await fn(...args)
      return result
    },
    subscribeCount(event) {
      return (handlers.get(event) ?? []).length
    },
    disposeAll() {
      for (const disposer of effects) {
        try {
          disposer?.()
        } catch (error) {
          console.log('dispose error:', error)
        }
      }
    },
  }
}

/** 从日志里抽出相位序列（状态机会打 "相位 → X"）。 */
const phases = (ctx) =>
  ctx.logs.filter(([, m]) => m.includes('相位 → ')).map(([, m]) => m.split('相位 → ')[1].trim())

console.log('plugin wiring')

await check('导出 name / apply', () => {
  assert.equal(name, 'taskbar-progress')
  assert.equal(typeof apply, 'function')
})

// ── 主场景 ────────────────────────────────────────────────────────────────
const services = {
  agents: {
    list: () => [
      { id: 'top', status: 'idle' },
      { id: 'sub', status: 'idle' },
    ],
    roots: () => [{ id: 'top', status: 'idle' }],
  },
}
const ctx = createFakeCtx(services)
apply(ctx, { backend: 'none', pollMs: 100_000, reassertMs: 0 })
await sleep(30)

await check('订阅了全部预期事件（含等待路径的三条）', () => {
  for (const event of [
    'agent/status',
    'api-session/status',
    'api-session/error',
    'agent/error',
    'api-session/removed',
    'agent/disposed',
    'user-questions/request', // 路径一：ask()
    'tools/execute', // 路径二：askTimed()（交互式提问实际走的）
    'approval/request', // 路径三：审批
  ]) {
    assert.ok(ctx.subscribeCount(event) > 0, `缺少 ${event} 订阅`)
  }
})

await check('启动即对齐为 idle', () => {
  assert.equal(phases(ctx).at(-1), 'idle')
})

await check('agent/status running → working', async () => {
  await ctx.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  assert.equal(phases(ctx).at(-1), 'working')
})

await check('子代理事件被 roots 过滤器挡住', async () => {
  const before = phases(ctx).length
  await ctx.emit('agent/status', { agent: { id: 'sub' }, status: 'running' })
  await ctx.emit('api-session/error', 'sub', 'child blew up')
  assert.equal(phases(ctx).length, before, '子代理不该产生相位变化')
})

await check('tools/execute：ask_user_question 挂起期间 → waiting，结束后回落', async () => {
  let release
  const gate = new Promise((resolve) => {
    release = resolve
  })
  let nextCalled = false
  const exec = { name: 'ask_user_question', callId: 'c1', agent: { id: 'top' } }
  const pending = ctx.emit('tools/execute', exec, async () => {
    nextCalled = true
    await gate
    return { isError: false, value: { answers: [] } }
  })
  await sleep(20)
  assert.equal(phases(ctx).at(-1), 'waiting', '提问挂起时应进入 waiting（黄色）')
  release()
  const result = await pending
  assert.equal(nextCalled, true, '必须原样调用 next()（观察性透传）')
  assert.deepEqual(result, { isError: false, value: { answers: [] } }, '必须原样返回下游结果')
  assert.equal(phases(ctx).at(-1), 'working', '回答后应回到 working')
})

await check('tools/execute：非等待类工具不产生 waiting', async () => {
  const before = phases(ctx).length
  await ctx.emit('tools/execute', { name: 'read', callId: 'c2', agent: { id: 'top' } }, async () => ({ isError: false }))
  assert.equal(phases(ctx).length, before, '普通工具不该触发 waiting')
})

await check('user-questions/request（ask 路径）→ waiting，且透传答案', async () => {
  const answer = { answers: [{ id: 'q1', selected: ['yes'] }] }
  const returned = await ctx.emit(
    'user-questions/request',
    { agent: { id: 'top' }, questions: [] },
    async () => answer,
  )
  assert.deepEqual(returned, answer, '必须原样返回下游答案')
  assert.ok(phases(ctx).includes('waiting'))
  assert.equal(phases(ctx).at(-1), 'working')
})

await check('approval/request → waiting，且透传结果', async () => {
  const outcome = { kind: 'allow' }
  const returned = await ctx.emit('approval/request', { agent: { id: 'top' } }, async () => outcome)
  assert.deepEqual(returned, outcome, '必须原样返回审批结果')
  assert.ok(phases(ctx).includes('waiting'))
  assert.equal(phases(ctx).at(-1), 'working')
})

await check('api-session/error → error（红色），粘性错误不重复触发', async () => {
  await ctx.emit('api-session/error', 'top', 'boom')
  assert.equal(phases(ctx).at(-1), 'error')
  const before = phases(ctx).length
  await ctx.emit('api-session/error', 'top', 'boom')
  await ctx.emit('api-session/error', 'top', 'boom')
  assert.equal(phases(ctx).length, before, '内容没变不该重复触发')
})

await check('重新开跑清掉故障 → working', async () => {
  await ctx.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  assert.equal(phases(ctx).at(-1), 'working')
})

await check('idle → done（完成保持态）', async () => {
  await ctx.emit('agent/status', { agent: { id: 'top' }, status: 'idle' })
  assert.equal(phases(ctx).at(-1), 'done')
})

await check('api-session/removed 清状态，不算完成', async () => {
  await ctx.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  assert.equal(phases(ctx).at(-1), 'working')
  await ctx.emit('api-session/removed', 'top')
  assert.equal(phases(ctx).at(-1), 'idle')
})

await check('插件停用时的清理不会抛错', () => {
  ctx.disposeAll()
})

// ── 配置规整 ──────────────────────────────────────────────────────────────
await check('缺省配置全部走默认值', async () => {
  const c = createFakeCtx()
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0 })
  await sleep(20)
  assert.deepEqual(phases(c), ['idle'])
  c.disposeAll()
})

await check('非法配置被拦下并回落到默认值', async () => {
  const c = createFakeCtx()
  apply(c, {
    backend: 'nonsense',
    scope: 'nonsense',
    completionHoldMs: 'not-a-number',
    flashOnWaiting: 'yes',
    waitingTools: 'ask_user_question',
    unknownKey: 1,
    pollMs: 100_000,
    reassertMs: 0,
  })
  await sleep(20)
  const warnings = c.logs.filter(([level]) => level === 'warn').map(([, m]) => m)
  assert.ok(warnings.some((m) => m.includes("backend") && m.includes('只能是')), `backend 应被拒绝：${warnings}`)
  assert.ok(warnings.some((m) => m.includes("scope")), 'scope 应被拒绝')
  assert.ok(warnings.some((m) => m.includes("completionHoldMs")), 'completionHoldMs 应被拒绝')
  assert.ok(warnings.some((m) => m.includes("flashOnWaiting")), 'flashOnWaiting 应被拒绝')
  assert.ok(warnings.some((m) => m.includes("waitingTools")), 'waitingTools 应被拒绝（需要字符串数组）')
  assert.ok(warnings.some((m) => m.includes("unknownKey")), '未知键应被提示')
  // 关键：坏值没有把插件打挂，仍然正常对齐到 idle
  assert.equal(phases(c).at(-1), 'idle')
  c.disposeAll()
})

await check('enabled=false 直接不接管', async () => {
  const c = createFakeCtx()
  apply(c, { enabled: false })
  await sleep(20)
  assert.equal(phases(c).length, 0, '禁用时不该产生任何相位')
  assert.equal(c.subscribeCount('agent/status'), 0, '禁用时不该订阅事件')
  c.disposeAll()
})

// ── 诊断日志 ──────────────────────────────────────────────────────────────
await check('debugLogFile 打开时会写 JSONL 诊断日志', async () => {
  const file = path.join(tmpdir(), `dsh-taskbar-debug-${process.pid}.jsonl`)
  rmSync(file, { force: true })
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, debugLogFile: file })
  await sleep(30)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await sleep(10)
  assert.ok(existsSync(file), '诊断文件应被创建')
  const lines = readFileSync(file, 'utf8').trim().split('\n').map((l) => JSON.parse(l))
  assert.ok(lines.some((l) => l.event === 'apply'), '应记录 apply')
  assert.ok(lines.some((l) => l.event === 'backend-ready'), '应记录 backend-ready')
  assert.ok(lines.some((l) => l.event === 'ev agent/status'), '应记录事件')
  c.disposeAll()
  rmSync(file, { force: true })
})

// ── 「等待用户」超时系统通知 ────────────────────────────────────────────────
// 用 setToastTransport 注入假发送器：验证"什么时候该弹"，不真的弹、不 spawn 进程。
const toastCalls = []
setToastTransport((options) => {
  toastCalls.push(options)
  return true
})

/** 进入等待 → 返回一个 release 函数，调用后结束等待。 */
async function enterWaiting(c) {
  let release
  const gate = new Promise((resolve) => {
    release = resolve
  })
  const pending = c.emit(
    'tools/execute',
    { name: 'ask_user_question', callId: 'c-wait', agent: { id: 'top' } },
    async () => {
      await gate
      return { isError: false }
    },
  )
  return { release, pending }
}

await check('等待超过阈值 → 弹一次系统通知（标题/正文/来源都对）', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingReminderMs: 80,
    notifyPersona: '大肥鱼',
    waitingReminderText: '老大请您做出决定',
  })
  await sleep(20)
  const { release, pending } = await enterWaiting(c)
  await sleep(220)
  assert.equal(toastCalls.length, 1, `应恰好弹一次，实际 ${toastCalls.length}`)
  assert.equal(toastCalls[0].title, '大肥鱼')
  assert.equal(toastCalls[0].text, '老大请您做出决定')
  assert.equal(toastCalls[0].aumid, 'com.deepseek.dsh')
  // 仍然在等待 → 不应重复弹
  await sleep(200)
  assert.equal(toastCalls.length, 1, '同一段等待只提醒一次')
  release()
  await pending
  await sleep(20)
  assert.equal(toastCalls.length, 1, '离开等待后不该再弹')
  c.disposeAll()
})

await check('阈值内作答 → 完全不提醒', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingReminderMs: 400 })
  await sleep(20)
  const { release, pending } = await enterWaiting(c)
  await sleep(60)
  release()
  await pending
  await sleep(500)
  assert.equal(toastCalls.length, 0, '及时作答不该提醒')
  c.disposeAll()
})

await check('waitingReminderMs=0 → 关闭提醒', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingReminderMs: 0 })
  await sleep(20)
  const { release, pending } = await enterWaiting(c)
  await sleep(200)
  assert.equal(toastCalls.length, 0, '关闭时不该提醒')
  release()
  await pending
  c.disposeAll()
})

await check('下一段等待会重新计时（用户作答后再问一次仍会提醒）', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingReminderMs: 80 })
  await sleep(20)
  const first = await enterWaiting(c)
  await sleep(180)
  assert.equal(toastCalls.length, 1, '第一次应提醒')
  first.release()
  await first.pending
  await sleep(30)
  const second = await enterWaiting(c)
  await sleep(180)
  assert.equal(toastCalls.length, 2, '第二次等待应重新提醒')
  second.release()
  await second.pending
  c.disposeAll()
})

// ── 「任务完成」后未操作 DSH → 「老大请验收」 ────────────────────────────────
/** 让假 ctx 走一遍 运行 → 完成，从而点亮 done 相位。 */
async function completeOnce(c) {
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'idle' })
}

await check('完成后未被操作 → 弹「老大请验收」', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingReminderMs: 0,
    completionNudgeMs: 80,
    notifyPersona: '大肥鱼',
    completionNudgeText: '老大请验收',
  })
  await sleep(20)
  await completeOnce(c)
  await sleep(260)
  assert.equal(toastCalls.length, 1, `应弹一次，实际 ${toastCalls.length}`)
  assert.equal(toastCalls[0].title, '大肥鱼', '发信人应是配置的 persona')
  assert.equal(toastCalls[0].text, '老大请验收')
  assert.equal(toastCalls[0].aumid, 'com.deepseek.dsh')
  c.disposeAll()
})

await check('完成时正在操作 DSH（前台 + 窗口内有过输入）→ 不打扰', async () => {
  toastCalls.length = 0
  // 同一个 completionNudgeMs 既是"等多久"，也是"多久内算操作过"的时间窗；
  // 测试里把它压到 300ms，所以模拟"刚输入过"要用更小的 idleMs。
  setActivityProbe(async () => ({ foregroundIsDsh: true, idleMs: 40 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingReminderMs: 0, completionNudgeMs: 300 })
  await sleep(20)
  await completeOnce(c)
  await sleep(420)
  assert.equal(toastCalls.length, 0, '正在操作时不该弹')
  c.disposeAll()
})

await check('DSH 在前台但长时间无输入（人走开了）→ 仍然提醒', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: true, idleMs: 60_000 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingReminderMs: 0, completionNudgeMs: 80 })
  await sleep(20)
  await completeOnce(c)
  await sleep(260)
  assert.equal(toastCalls.length, 1, '人走开了应该提醒')
  c.disposeAll()
})

await check('探测失败 → fail-open（宁可多提醒，不吞掉完成事件）', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => undefined)
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingReminderMs: 0, completionNudgeMs: 80 })
  await sleep(20)
  await completeOnce(c)
  await sleep(260)
  assert.equal(toastCalls.length, 1, '探测失败时应照常提醒')
  c.disposeAll()
})

await check('completionNudgeMs=0 → 关闭完成提醒', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 99_999 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingReminderMs: 0, completionNudgeMs: 0 })
  await sleep(20)
  await completeOnce(c)
  await sleep(220)
  assert.equal(toastCalls.length, 0, '关闭时不该提醒')
  c.disposeAll()
})

await check('完成提醒在离开 done 后取消（不会延迟补弹）', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 99_999 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingReminderMs: 0, completionNudgeMs: 300 })
  await sleep(20)
  await completeOnce(c)
  // 在提醒到点前用户又开跑了 → 相位离开 done
  await sleep(60)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await sleep(400)
  assert.equal(toastCalls.length, 0, '离开 done 后应取消提醒')
  c.disposeAll()
})

setActivityProbe(null)
setToastTransport(null)

console.log(`\nplugin wiring: ${passed} 项全部通过\n`)
